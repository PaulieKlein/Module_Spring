package com.bankonet.report;

public class HtmlReportGenerator implements IReportGenerator {

	public void generate() {
		System.out.println("G�n�ration d'un rapport HTML.");
	}

	
}
