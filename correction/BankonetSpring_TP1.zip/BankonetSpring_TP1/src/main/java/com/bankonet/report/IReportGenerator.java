package com.bankonet.report;

public interface IReportGenerator {

	public void generate();
	
}
