package com.bankonet.report;

public abstract class ReportGenerator {
	
	
}
